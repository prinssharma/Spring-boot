package com.example.ComputerProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComputerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComputerProjectApplication.class, args);
	}

}
