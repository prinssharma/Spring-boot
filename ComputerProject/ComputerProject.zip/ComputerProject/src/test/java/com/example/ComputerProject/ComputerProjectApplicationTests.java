package com.example.ComputerProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComputerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
